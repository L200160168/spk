<!DOCTYPE html>
<html>
<head>
	<?php
	error_reporting(E_ALL ^ E_NOTICE^E_DEPRECATED);
	?>
	<title>j</title>
</head>
<body>
	<div class="margin"><input type="submit" class="btn btn-danger m-b-10" name="tambah" value="+Tambah"></div>
	<P><a href="penilaian_upload">aja</a></P>
	<CENTER><input type="submit" class="btn btn-primary m-b-10" name="submite" value="LOGIN"></CENTER>

</body>
		<?php
        


        if($submite){
        	?>
            <script>
                alert('Data Berhasil Dimasukkan');
                document.location='penilaian_upload.php';
            </script>
            <?php
                
            }
        
        ?>

</html>