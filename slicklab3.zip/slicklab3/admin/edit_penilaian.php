
<?php
error_reporting(E_ALL^E_NOTICE^E_DEPRECATED);
include('koneksi.php');

$kode = $_GET['kode_penilaian'];
$nip = $_GET['nip'];
$nilai_pp= $_GET['nilai_pp'];
$nilai_k1 = $_GET['nilai_k1'];
$nilai_k2 = $_GET['nilai_k2'];
$nilai_k3 = $_GET['nilai_k3'];
$usia = $_GET['usia'];
$total = $_GET['total'];

//query update
$query = "UPDATE user SET nip='$nama' , nilai_pp='$nilai_pp', nilai_k1='$nilai_k1', nilai_k2='$nilai_k2', nilai_k3='$nilai_k3', usia='$usia', total='$total'  WHERE kode='$kode' ";

if (mysqli_query($conn,$query)) {
 # credirect ke page index
 header("location:penilaian_manager.php"); 
}
else{
 echo "ERROR, data gagal diupdate";
}

//mysql_close($host);
?>