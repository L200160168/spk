<!DOCTYPE html>
<html lang="en">
<head>
    <?php
            error_reporting(E_ALL ^ E_NOTICE^E_DEPRECATED);
            include "koneksi.php";
    ?>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Mosaddek">
    <meta name="keyword" content="slick, flat, dashboard, bootstrap, admin, template, theme, responsive, fluid, retina">
    <link rel="shortcut icon" href="javascript:;" type="image/png">

    <title>Penilaian Karyawan</title>

    <!--right slidebar-->
    <link href="css/slidebars.css" rel="stylesheet">

    <!--switchery-->
    <link href="js/switchery/switchery.min.css" rel="stylesheet" type="text/css" media="screen" />

    <!--Data Table-->
    <link href="js/data-table/css/jquery.dataTables.css" rel="stylesheet">
    <link href="js/data-table/css/dataTables.tableTools.css" rel="stylesheet">
    <link href="js/data-table/css/dataTables.colVis.min.css" rel="stylesheet">
    <link href="js/data-table/css/dataTables.responsive.css" rel="stylesheet">
    <link href="js/data-table/css/dataTables.scroller.css" rel="stylesheet">
    <!-- Base Styles -->

    <!--common style-->
    <link href="css/style.css" rel="stylesheet">
    <link href="css/style-responsive.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->
</head>

<body class="sticky-header">

    <section>
        <!-- sidebar left start-->
        <div class="sidebar-left">
            <!--responsive view logo start-->
            <div class="logo dark-logo-bg visible-xs-* visible-sm-*">
                <a href="index.html">
                    <img src="img/logo-icon.png" alt="">
                    <!--<i class="fa fa-maxcdn"></i>-->
                    <span class="brand-name">SlickLab</span>
                </a>
            </div>
            <!--responsive view logo end-->

            <div class="sidebar-left-info">
                <!-- visible small devices start-->
                <div class=" search-field">  </div>
                <!-- visible small devices end-->

                <!--sidebar nav start-->
                <ul class="nav nav-pills nav-stacked side-navigation">
                    <li>
                        <h3 class="navigation-title">Navigation</h3>
                    </li>
                    <li><a href="home_manager.php"><i class="fa fa-home"></i> <span>Home</span></a></li>
                    
                    
                    <li>
                        <h3 class="navigation-title">Components</h3>
                    </li>
                    

                            <li><a href="karyawan_manager.php"><i class="fa fa-th-list"></i> Karyawan</a></li>
                            <li><a href="penilaian_manager.php"><i class="fa fa-th-list"></i> Penilaian</a></li>
                            <li><a href="admin_manager.php"><i class="fa fa-th-list"></i> Admin</a></li>

                   

                    
                    <li>
                        <h3 class="navigation-title">Extra</h3>
                    </li>

                    <li class="menu-list"><a href="javascript:;"><i class="fa fa-envelope-o"></i> <span>Email <span class="label noti-arrow bg-danger pull-right">4 Unread</span> </span></a>
                        <ul class="child-list">
                            <li><a href="inbox.html"> Inbox</a></li>
                            <li><a href="inbox-details.html"> View Mail</a></li>
                            <li><a href="inbox-compose.html"> Compose Mail</a></li>
                        </ul>
                    </li>

                    

                </ul>
                <!--sidebar nav end-->

                <!--sidebar widget start-->
                
                <!--sidebar widget end-->

            </div>
        </div>
        <!-- sidebar left end-->

        <!-- body content start-->
        <div class="body-content" style="min-height: 1000px;">

            <!-- header section start-->
            <div class="header-section">

                <!--logo and logo icon start-->
                <div class="logo dark-logo-bg hidden-xs hidden-sm">
                    <a href="home_manager.php">
                        <img src="img/logo-icon.png" alt="">
                        <!--<i class="fa fa-maxcdn"></i>-->
                        <span class="brand-name">SlickLab</span>
                    </a>
                </div>

                <div class="icon-logo dark-logo-bg hidden-xs hidden-sm">
                    <a href="home_manager.php">
                        <img src="img/logo-icon.png" alt="">
                        <!--<i class="fa fa-maxcdn"></i>-->
                    </a>
                </div>
                <!--logo and logo icon end-->

                <!--toggle button start-->
                <a class="toggle-btn"><i class="fa fa-outdent"></i></a>
                <!--toggle button end-->

                <!--mega menu start-->
                
                <!--mega menu end-->
                <div class="notification-wrap">
                <!--left notification start-->
                <div class="left-notification">
                <ul class="notification-menu">
                <!--mail info start-->
                
                <!--mail info end-->

                <!--task info start-->
                
                <!--task info end-->

                <!--notification info start-->
                
                <!--notification info end-->
                </ul>
                </div>
                <!--left notification end-->


                <!--right notification start-->
                <div class="right-notification">
                    <ul class="notification-menu">
                        <li>
                            <form class="search-content" action="home_manager.php" method="post">
                                <input type="text" class="form-control" name="keyword" placeholder="Search...">
                            </form>
                        </li>

                        <li>
                            <a href="javascript:;" class="btn btn-default dropdown-toggle" data-toggle="dropdown">
                                <img src="img/avatar-mini.jpg" alt="">John Doe
                                <span class=" fa fa-angle-down"></span>
                            </a>
                            <ul class="dropdown-menu dropdown-usermenu purple pull-right">
                                <li><a href="javascript:;">  Profile</a></li>
                                <li>
                                    <a href="javascript:;">
                                        <span class="badge bg-danger pull-right">40%</span>
                                        <span>Settings</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="javascript:;">
                                        <span class="label bg-info pull-right">new</span>
                                        Help
                                    </a>
                                </li>
                                <li><a href="login.html"><i class="fa fa-sign-out pull-right"></i> Log Out</a></li>
                            </ul>
                        </li>                      
                    </ul>
                </div>
                <!--right notification end-->
                </div>

            </div>
            <!-- header section end-->

           <!--body wrapper start-->
            <div class="col-lg-30">
                    <section class="panel">
                        <header class="panel-heading">
                            Input Admin
                        </header>
                        <div class="panel-body">
                            <form class="form-horizontal" role="form" action='input_admin.php' method='POST' name='input_admin'>
                                <div class="form-group">
                                    <label for="inputusername" class="col-lg-2 col-sm-2 control-label">Username</label>
                                    <div class="col-lg-10">
                                        <input type="text" class="form-control"  name='user'>
                                        <p class="help-block">Max 10 Karakter</p>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="inputfullname" class="col-lg-2 col-sm-2 control-label">Nama Lengkap</label>
                                    <div class="col-lg-10">
                                        <input type="text" class="form-control"  name='nama'>
                                        <p class="help-block">Tulis Nama Lengkap Tanpa Disingkat</p>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="inputpass" class="col-lg-2 col-sm-2 control-label">Password</label>
                                    <div class="col-lg-10">
                                        <input type="password" class="form-control"  name='pass'>
                                        <p class="help-block">Padukan karakter dan abjad</p>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="inputemail" class="col-lg-2 col-sm-2 control-label">Email</label>
                                    <div class="col-lg-10">
                                        <input type="text" class="form-control" name='email'>
                                        <p class="help-block">.yooo atau .gmail</p>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="inputfullname" class="col-lg-2 col-sm-2 control-label">Status</label>
                                    <div class="col-lg-10">
                                    <select class="form-control m-b-10" name='status'>
                                        <option >--Pilih Salah Satu--</option>
                                        <option name='status' value="Kepala Bagian" >Kepala Bagian</option>
                                        <option name='status' value="Manager">Manager</option>
                                    </select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-lg-offset-2 col-lg-10">
                                        <input class="btn btn-primary m-b-10" type="submit" name="submit"></input> &nbsp;&nbsp;
                                        <input class="btn btn-danger m-b-10" type="reset" name="reset"></input>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </section>
                </div>
                         
<style type="text/css">
    .margin{
        margin-left: 1100px;
        margin-bottom: -17px;
        margin-top: 35px;    
    }
    .admin{
        margin-left: 3px;
        margin-bottom: -55px;
        margin-top: -16px; 
    }
</style>        
           
            

<!-- Placed js at the end of the document so the pages load faster -->
<script src="js/jquery-1.10.2.min.js"></script>
<script src="js/jquery-migrate.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/modernizr.min.js"></script>

<!--Nice Scroll-->
<script src="js/jquery.nicescroll.js" type="text/javascript"></script>

<!--right slidebar-->
<script src="js/slidebars.min.js"></script>

<!--switchery-->
<script src="js/switchery/switchery.min.js"></script>
<script src="js/switchery/switchery-init.js"></script>

<!--Sparkline Chart-->
<script src="js/sparkline/jquery.sparkline.js"></script>
<script src="js/sparkline/sparkline-init.js"></script>


<!--common scripts for all pages-->
<script src="js/scripts.js"></script>



<?php
error_reporting(E_ALL ^ E_NOTICE ^ E_DEPRECATED);
$user = $_POST['user'];
$nama = $_POST['nama'];
$pass = $_POST['pass'];
$email = $_POST['email'];
$status = $_POST['status'];
$submit = $_POST['submit'];
include "koneksi.php";
if($submit){
    $sql="insert into user(username,nama,password,email,status)
    values ('$user','$nama','$pass','$email','$status')";
    $query=mysqli_query($conn,$sql);
    if($query){
        ?>
        <script language script="JavaScript">alert('Data Berhasil Ditambahkan');
        document.location='admin_manager.php';</script>
        <?php
    }else{
        ?>
        <script language script="JavaScript">alert('Username Pernah Dimasukkan');</script>
        <?php
    }
}
?>

</body>
</html>
