<?php
error_reporting(E_ALL^E_NOTICE^E_DEPRECATED);
include('koneksi.php');

$username = $_GET['username_admin'];
$nama = $_GET['nama_admin'];
$password= $_GET['pass_admin'];
$email = $_GET['email_admin'];
$status = $_GET['status_admin'];

//query update
$query = "UPDATE user SET nama='$nama' , password='$password', email='$email', status='$status' WHERE username='$username' ";

if (mysqli_query($conn,$query)) {
 # credirect ke page index
 header("location:admin_manager.php"); 
}
else{
 echo "ERROR, data gagal diupdate";
}

//mysql_close($host);
?>