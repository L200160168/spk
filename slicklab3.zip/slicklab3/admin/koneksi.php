<?php
error_reporting(E_ALL^E_NOTICE);
$host="localhost";
$username="root";
$password="";
$db="spk";
$conn=mysqli_connect($host,$username,$password,$db) or die ("koneksi gagal");
echo "h";
?>