<!DOCTYPE html>
<html lang="en">
<?php
session_start();
error_reporting(E_ALL^E_NOTICE^E_DEPRECATED);
include 'koneksi.php';
?>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Admin Template">
    <meta name="keywords" content="admin dashboard, admin, flat, flat ui, ui kit, app, web app, responsive">
    <link rel="shortcut icon" href="img/ico/favicon.png">
    <title>themelock.com - Login</title>

    <!-- Base Styles -->
    <link href="css/style.css" rel="stylesheet">
    <link href="css/style-responsive.css" rel="stylesheet">
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script src="js/html5shiv.min.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->


</head>

  <body class="login-body">

      <div class="login-logo">
          <img src="img/login_logo.png" alt=""/>
      </div>

      <h2 class="form-heading">login</h2>
      <div class="container log-row">
          <form class="form-signin" action="login.php" method="post">
              <div class="login-wrap">
                  <input type="text" name="username" class="form-control" placeholder="User ID" autofocus>
                  <input type="password" name="password" class="form-control" placeholder="Password">
                  <CENTER><input type="submit" class="btn btn-primary m-b-10" name="submite" value="LOGIN"></CENTER>
                  <div class="login-social-link">
                      <a href="#" class="facebook">
                          Facebook
                      </a>
                      <a href="#" class="twitter">
                          Twitter
                      </a>
                  </div>
                  <label class="checkbox-custom check-success">
                      <input type="checkbox" value="remember-me" id="checkbox1"> <label for="checkbox1">Remember me</label>
                      <a class="pull-right" data-toggle="modal" href="#forgotPass"> Forgot Password?</a>
                  </label>

                  <div class="registration">
                      Don't have an account yet?
                      <a class="" href="registration.html">
                          Create an account
                      </a>
                  </div>

              </div>

              <!-- Modal -->
              <div aria-hidden="true" aria-labelledby="myModalLabel" role="dialog" tabindex="-1" id="forgotPass" class="modal fade">
                  <div class="modal-dialog">
                      <div class="modal-content">
                          <div class="modal-header">
                              <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                              <h4 class="modal-title">Forgot Password ?</h4>
                          </div>
                          <div class="modal-body">
                              <p>Enter your e-mail address below to reset your password.</p>
                              <input type="text" name="email" placeholder="Email" autocomplete="off" class="form-control placeholder-no-fix">

                          </div>
                      </div>
                  </div>
              </div>
              <!-- modal -->

          </form>
          <?php
          error_reporting(E_ALL^E_NOTICE^E_DEPRECATED);
          $username = $_POST['username'];
          $password = $_POST['password'];
          $submite  = $_POST['submite'];

          if($submite){
            $sql = "SELECT * FROM user WHERE username='$username' and password='$password'";
            $query = mysqli_query($conn,$sql);
            $hasil = mysqli_fetch_array($query);
            
            if($hasil[status]=="kepala_bagian"){
              $_SESSION['username']=$hasil[username];
              $_SESSION['password']=$hasil[password];
              $_SESSION['status']=$hasil[status];
              ?>
              <script type="text/javascript">alert("Anda masuk sebagi kepala bagian"); document.location="home_kb.php"; </script>
              <?php
            }elseif ($hasil[status]=="manajer"){
              $_SESSION['username']=$hasil[username];
              $_SESSION['password']=$hasil[password];
              $_SESSION['status']=$hasil[status];
              ?>
              <script type="text/javascript">alert("Anda masuk sebagai manajer"); document.location="home_manager.php" </script>
              <?php
            }else{
              ?>
              <script type="text/javascript">alert("Gagal login silakan coba lagi"); document.location="login.php" </script>
              <?php
            }
          }
          ?>
      </div>

      <!--jquery-1.10.2.min-->
      <script src="js/jquery-1.11.1.min.js"></script>
      <!--Bootstrap Js-->
      <script src="js/bootstrap.min.js"></script>
      <script src="js/jrespond..min.js"></script>

  </body>
</html>
